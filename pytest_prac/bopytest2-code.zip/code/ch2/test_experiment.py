import cards


def test_no_path_fail():
    cards.CardsDB()
