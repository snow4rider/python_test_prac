def test_passing():
    assert (1, 2, 3) == (1, 2, 3)
