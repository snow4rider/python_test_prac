def bar():
    return "bar"


def baz():
    return "baz"
