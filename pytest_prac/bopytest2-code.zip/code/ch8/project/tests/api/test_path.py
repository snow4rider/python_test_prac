import sys
from pprint import pprint


def test_path():
    print("sys.path:")
    pprint(sys.path)
