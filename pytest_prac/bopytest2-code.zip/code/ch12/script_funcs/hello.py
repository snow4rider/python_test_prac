def full_output():
    return "Hello, World!"


def main():
    print(full_output())


if __name__ == "__main__":
    main()
