import time


def one():
    return 1


def two():
    return 2


def three():
    time.sleep(2)
    return 3
